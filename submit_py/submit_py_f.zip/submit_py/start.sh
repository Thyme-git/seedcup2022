/bin/bash ./prepare.sh
python client/main_nonrl.py # Maybe you need to change to your main program entry